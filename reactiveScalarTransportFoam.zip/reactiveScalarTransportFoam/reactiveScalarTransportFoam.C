/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           |
     \\/     M anipulation  |
\*---------------------------------------------------------------------------*/

#include "fvCFD.H"
#include "fvModels.H"
#include "fvConstraints.H"
#include "simpleControl.H"

#include <fstream>  // for hotness time series output

int main(int argc, char *argv[])
{
    #include "setRootCaseLists.H"
    #include "createTime.H"
    #include "createMesh.H"

    simpleControl simple(mesh);

    #include "createFields.H"

    Info<< "\nCalculating scalar transport\n" << endl;

    #include "CourantNo.H"

    while (simple.loop(runTime))
    {
        Info<< "Time = " << runTime.userTimeName() << nl << endl;

        fvModels.correct();

        while (simple.correctNonOrthogonal())
        {
            fvScalarMatrix TEqn
            (
                fvm::ddt(T)
              + fvm::div(phi, T)
              - fvm::laplacian(DT, T)
             ==
                fvModels.source(T)
            );

            TEqn.relax();
            fvConstraints.constrain(TEqn);
            TEqn.solve();
            fvConstraints.constrain(T);
        }

        // --------------------------------------------------------------
        // Only compute j, jWall, and H when controlDict says to write
        // (e.g. writeControl runTime; writeInterval 10;)
        // j and jWall are global fields (created in createFields.H)
        // --------------------------------------------------------------
        if (runTime.outputTime())
        {
            // Reset flux fields
            j = dimensionedScalar
            (
                "zero",
                j.dimensions(),
                0.0
            );

            jWall = dimensionedScalar
            (
                "zero",
                jWall.dimensions(),
                0.0
            );

            const scalar DTval = DT.value();   // constant scalar diffusivity

            // Compute j and jWall on reactive walls
            forAll (T.boundaryField(), patchI)
            {
                const fvPatchScalarField& Tp = T.boundaryField()[patchI];

                if (Tp.type() != "reactiveWallFlux")
                {
                    continue;
                }

                const scalarField& snGradT =
                    Tp.snGrad();   // [T]/[L], outward from fluid

                // Face-based flux j = -DT * snGrad(T)
                scalarField& jWallPatch = jWall.boundaryFieldRef()[patchI];
                jWallPatch = -DTval * snGradT;

                // Copy face value to cell-centred boundary field
                scalarField& jPatch = j.boundaryFieldRef()[patchI];
                jPatch = jWallPatch;
            }

            // --- Hotness H(t) and reaction-region measure |R| ----------
            scalar totalArea = 0.0;   // |R| = total reactive area (or length in 2D/unit-depth)
            scalar sumJ      = 0.0;
            scalar sumJ2     = 0.0;

            forAll (T.boundaryField(), patchI)
            {
                const fvPatchScalarField& Tp = T.boundaryField()[patchI];

                if (Tp.type() != "reactiveWallFlux")
                {
                    continue;
                }

                const scalarField& jPatch =
                    jWall.boundaryField()[patchI];

                const scalarField& magSfPatch =
                    mesh.magSf().boundaryField()[patchI];

                // |R| = ∑_f A_f over all reactive faces
                totalArea += gSum(magSfPatch);

                // ∫_R j dS ≈ ∑ j_f A_f
                sumJ      += gSum(jPatch * magSfPatch);

                // ∫_R j^2 dS ≈ ∑ j_f^2 A_f
                sumJ2     += gSum(sqr(jPatch) * magSfPatch);
            }

            scalar H = 1.0;
            if (sumJ > VSMALL)
            {
                H = totalArea * sumJ2 / sqr(sumJ);
            }

            // Print both |R| and H to the log
            Info<< "  |R| (reaction-region measure) = " << totalArea << nl;
            Info<< "  Hotness H = " << H << nl << endl;

            // Append to a simple ASCII file: hotness.dat in case directory
            // Columns: time   H   |R|
            {
                const fileName hotFileName(runTime.globalPath()/"hotness.dat");
                std::ofstream hotFile(hotFileName.c_str(), std::ios::app);

                hotFile << runTime.value() << " " << H << " " << totalArea << std::endl;
            }

            // Optional: write H as a volume field if you want to see it in ParaView
            /*
            volScalarField HField
            (
                IOobject
                (
                    "HField",
                    runTime.timeName(),
                    mesh,
                    IOobject::NO_READ,
                    IOobject::AUTO_WRITE
                ),
                mesh,
                dimensionedScalar("H", dimless, H)
            );
            HField.write();
            */

            // Explicit writes are optional; runTime.write() below will
            // also write all AUTO_WRITE fields (including j and jWall).
            j.write();
            jWall.write();
        }
        // --------------------------------------------------------------

        runTime.write();
    }

    Info<< "End\n" << endl;

    return 0;
}


// ************************************************************************* //

