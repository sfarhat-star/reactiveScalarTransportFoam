#include "reactiveWallFluxFvPatchScalarField.H"
#include "addToRunTimeSelectionTable.H"
#include "fvPatchFieldMapper.H"
#include "volFields.H"

namespace Foam
{

// Construct from patch & internal field
reactiveWallFluxFvPatchScalarField::reactiveWallFluxFvPatchScalarField
(
    const fvPatch& p,
    const DimensionedField<scalar, volMesh>& iF
)
:
    fixedGradientFvPatchField<scalar>(p, iF),
    k_(0.0)
{}


// Construct from patch, internal field & dictionary
reactiveWallFluxFvPatchScalarField::reactiveWallFluxFvPatchScalarField
(
    const fvPatch& p,
    const DimensionedField<scalar, volMesh>& iF,
    const dictionary& dict
)
:
    fixedGradientFvPatchField<scalar>(p, iF),
    k_(readScalar(dict.lookup("k")))
{
    if (dict.found("value"))
    {
        // Read initial patch values from the dictionary
        fvPatchScalarField::operator=
        (
            scalarField("value", dict, p.size())
        );
    }
    else
    {
        // Default: initialize from internal field
        fvPatchScalarField::operator=(this->patchInternalField());
    }
}


// Mapping constructor
reactiveWallFluxFvPatchScalarField::reactiveWallFluxFvPatchScalarField
(
    const reactiveWallFluxFvPatchScalarField& ptf,
    const fvPatch& p,
    const DimensionedField<scalar, volMesh>& iF,
    const fvPatchFieldMapper& mapper
)
:
    fixedGradientFvPatchField<scalar>(ptf, p, iF, mapper),
    k_(ptf.k_)
{}


// Copy constructor with new internal field
reactiveWallFluxFvPatchScalarField::reactiveWallFluxFvPatchScalarField
(
    const reactiveWallFluxFvPatchScalarField& ptf,
    const DimensionedField<scalar, volMesh>& iF
)
:
    fixedGradientFvPatchField<scalar>(ptf, iF),
    k_(ptf.k_)
{}


// Apply Robin BC: snGrad(A) = -k_ * A
// Physical flux (fluid -> wall): j = -D * snGrad(A) = D * k_ * A
void reactiveWallFluxFvPatchScalarField::updateCoeffs()
{
    if (this->updated())
    {
        return;
    }

    const scalarField& Ap = *this;

    // Outward normal gradient on the patch
    this->gradient() = -k_ * Ap;

    fixedGradientFvPatchField<scalar>::updateCoeffs();
}

} // End namespace Foam


// Runtime selection table
namespace Foam
{
    makePatchTypeField(fvPatchScalarField, reactiveWallFluxFvPatchScalarField);
}
